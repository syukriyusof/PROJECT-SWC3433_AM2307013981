<html>
<head>
 <title>Table Booked Restaurant Nisaa</title>
</head>
<body>
 <h3>Table Booked Restaurant Nisaa</h3>

 <form action="displayRecord.php" method="post">
 Customer Name: <input name="name" type="text" size="30"><br><br>
 <input type="submit" name="Submit" value="Search">
 </form>
 <p><a href="adminMenu.php">Back to Main Menu</a></p>
</body>
</html>
