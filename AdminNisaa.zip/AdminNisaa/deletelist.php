<html>
<head>
 <title>Table Booked Restaurant Nisaa</title>
</head>
<body>
 <form action="deleteRecord.php" method="post">
 Customer Name: <input type="text" name="name" size="30">
 <input type="submit" name="submit">
 </form>
 <p><a href="adminMenu.php">Back to Main Menu</a></p>
</body>
</html>