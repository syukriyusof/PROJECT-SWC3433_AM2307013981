<?php
$servername="localhost"; // Host name
$username="root"; // Mysql username
$password=""; // Mysql password
$dbName="adnisaa"; // Database name
// Create connection
$conn = new mysqli($servername, $username, $password, $dbName);
// Check connection
if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
}
// Define $myusername and $mypassword
$myusername=$_POST['username'];
$mypassword=$_POST['password'];

$sql= "SELECT *FROM login WHERE username ='$username' AND password='$password'";
$result = $conn->query($sql);
// Mysql_num_row is counting table row
if($result->num_rows == 0)
{
 //redirect to file "adminMenu.php"
 header("location:adminMenu.php");
}
else
{
 echo "<p>Wrong Username or Password. Please try again.";
}
$conn->close();
?>