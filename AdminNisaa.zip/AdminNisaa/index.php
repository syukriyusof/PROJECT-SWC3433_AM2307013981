<html>
<head>
 <title>Login Page</title>
</head>
<body>
 <form action="loginauto.php" method="post">
 <table align="center">
 <tr>
 <td colspan="3" align="center"><b>Nisaa's Admin Login</b></td>
 </tr>
 <tr>
 <td>Username</td>
 <td>:</td>
 <td><input name="username" type="text"/></td>
 </tr>
 <tr>
 <td>Password</td>
 <td>:</td>
 <td><input name="password" type="password"/></td>
 </tr>
 <tr>
 <td>&nbsp;</td>
 <td>&nbsp;</td>
 <td><input name="Submit" type="submit" value="Login" /></td>
 </tr>
 </table>
 </form>
</body>
</html>