<?php
$con = mysqli_connect("localhost","root","","nisaa") or die(mysql_error());

?>