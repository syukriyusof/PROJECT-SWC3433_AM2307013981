<?php
include('nisaa.php')
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Nisaa</title>
	<link rel="stylesheet" href="style.css">
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
	<!-- Navbar -->
	<header>
		<nav>
			<ul class="left-links" type="none">
				<li><a href="#about" class="link">
					about 
				</a></li>
				<li><a href="#menu" class="link">
					menu
				</a></li>
				<li><a href="#gallery" class="link">
					gallery
				</a></li>
			</ul>
			<a href="#home" class="logo">
				<img src="./image/logo nisaa.png" alt="" width="150" height="86">
			</a>
			<ul class="right-links" type="none">
				<li><a href="#contact" class="link">
					contact 
				</a></li>
				<li><a href="booking.php" class="link">
					reservations
				</a></li>
			</ul>
		</nav>
	</header>
	<!--Home Page -->
	<section id="home" class="home">
		<div class="left">
			<p align="center"><img src="./image/makanan.png" alt="" width="500" height="500"></p>
		</div>
		<div class="right">
			<div class="top">
				<p>
					Start your meal with our exlusive menu
				</p>
				<a href="#gallery" class="link">
					learn more...
				</a>
			</div>
			<div class="middle">
				<img src="./image/logo nisaa.png" alt="">
			</div>
			
			<div class="bottom">
				<a href="booking.php" class="link">
				book your <br> table <span>now</span> 
				</a>
			</div>
			<img src="home footer.png" class="home-footer" alt="">
		</div>	
	</section>
	<!-- about us page -->
	<section class="about" id="about">
		<div class="about-text">
			<div class="title">
				<img src="./image/yellow wave.png" alt="">
				<p>ABOUT <span>Nisaa</span></p>
				<img src="./image/yellow wave.png" alt="">
			</div>
			<p class="des">
			Restoran Nisaa has started since 2010 and now we have been operating for more than a decade. We serve a variety of cuisine that meets the tastes of Malaysians. The cuisines we serve include Japanese, Korean, Chinese and westerns.
			</p>
			<a href="booking.php" class="link">
				Visit or Book <span>Now</span>
			</a>
		</div>
	</section>
	<!-- menu page -->
	<section class="menu" id="menu">
		<img src="./image/hand.png" class="hand" alt="">
		<div class="menu-text">
			<div class="title">
				<img src="./image/white wave.png" alt="">
				<p>OUR FOOD QUALITY</p>
				<img src="./image/white wave.png" alt="">
			</div>
			<p class="des">
			The taste and quality of our food is undeniable, by using high quality imported ingredients. We can guarantee that the taste of our food will have nothing in common with the food in the market. Our professional chefs are also always committed in ensuring our food always meets the standards of our restaurant.
			</p>
			<div class="discount">
				<p>
					double the fun <span> on every saturday</span>
				</p>
				<p>get upto 50% discount</p>
			</div>
		</div>
	</section>
	<!-- gallery -->
	<section class="gallery" id="gallery">
		<div class="title">
				<img src="./image/yellow wave.png" alt="">
				<p>GALLERY</p>
				<img src="./image/yellow wave.png" alt="">
		</div>
		<div class="gallery-image">
			<div>
				<img src="./image/g1-min.png" alt="">
				<img src="./image/g2-min.png" alt="">
			</div>
			<div>
				<img src="./image/g3-min.png" alt="">
				<img src="./image/g4-min.png" alt="">
				<img src="./image/g5-min.png" alt="">
			</div>
			<div>
				<img src="./image/g6-min.png" alt="">
				<img src="./image/g7-min.png" alt="">
			</div>
		</div>
	</section>

	
			<!-- ?php
			$con=mysqli_connect("localhost","root","","nisaa");
			$check="SELECT * FROM booking WHERE PhoneNumber = '$_POST[PhoneNumber]'";
									$rs = mysqli_query($con,$check);
									$rs = mysqli_query($con,$check);
									$data = mysqli_fetch_array($rs, MYSQLI_NUM);
									if($data[0] > 1) {
										echo "<script type='text/javascript'> alert('User Already in Exists')</script>";
										
									}

									else
									
										$newUser="INSERT INTO booking('Name', 'Pax', 'Date', 'Email', 'Time', 'PhoneNumber') VALUES ('{$_POST['Name']}','{$_POST['Pax']}','{$_POST['Date']}','{$_POST['Email']}','{$_POST['Time']}','{$_POST['PhoneNumber']}')";

										if (mysqli_query($con,$newUser))
										{
											echo "<script type='text/javascript'> alert('Your Booking application has been sent')</script>";
											
										}
										else
										{
											echo "<script type='text/javascript'> alert('Error adding user in database')</script>";
											
							
						}
							?>-->

		</form>
	</section>
	<!-- contact -->
	<section class="contact" id="contact">
		<img src="./image/g5-min.png" alt="">
		<div class="para">
		<i class='bx bxs-quote-left'></i>
		<p>
			We are committed in providing the best meals for our customers. Customer satisfaction is our priority.
		</p>
		<h1 class="name">SYUKRI YUSOF</h1>
		</div>
	</section>
	<div class="contact-box">
		<div class="text">
			<h2>Enjoy Our Best Meal</h2>
			<p>
				Nisaa provide various type of food that will trigger your appetite. From korean, japanese to west cuisine is served to satisfied our customer mouth and stomach.
			</p>
			<p>CONTACT US NOW</p>
		</div>
		<img src="./image/foodplate.png" alt="">
	</div>
	<!-- footer -->
	<footer>
		<a href="#home">
			<img src="./image/logo nisaa.png" alt="">
		</a>
		<ul class="links" type="none">
			<li class="link">
				<a href="#about">ABOUT US</a>
			</li>
			<li class="link">
				<a href="#menu">MENU</a>
			</li>
			<li class="link">
				<a href="#gallery">GALLERY</a>
			</li>
			<li class="link">
				<a href="#booking">RESERVATION</a>
			</li>
			<li class="link">
				<a href="#contact">CONTACT</a>
			</li>
		</ul>
		<div class="box-icon">
			<a href="https://www.facebook.com/profile.php?id=100057588035273">
			<i class='bx bxl-facebook'></i>
			</a>
			<a href="https://www.instagram.com/restorannisaa/?hl=en">
			<i class='bx bxl-instagram'></i>
			</a>
			<a href="https://www.tiktok.com/@restorannisaa">
			<i class='bx bxl-tiktok'></i>
			</a>
		</div>
	</footer>
</body>
</html>


